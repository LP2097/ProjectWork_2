package thunderbytes.com.formulanews.Helpers;

public class Constants {
    public static final String baseUrl = "https://ergast.com/api/f1/";
}
