package thunderbytes.com.formulanews.Tasks;

import android.os.AsyncTask;
import thunderbytes.com.formulanews.Models.Constructor;

public class DbTask extends AsyncTask<Constructor, Void, Constructor> {
    protected Constructor doInBackground(Constructor... urls) {
      return null;
    }


    protected void onPostExecute(Constructor response){

    }
}
