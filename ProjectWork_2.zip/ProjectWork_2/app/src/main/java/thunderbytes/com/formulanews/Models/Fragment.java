package thunderbytes.com.formulanews.Models;

import java.io.Serializable;

public class Fragment implements Serializable {
    public int fragmentId;
    public String fragmentTitle;
}
