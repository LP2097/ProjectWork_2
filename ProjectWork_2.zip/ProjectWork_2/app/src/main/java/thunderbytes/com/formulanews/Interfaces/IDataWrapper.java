package thunderbytes.com.formulanews.Interfaces;

public interface IDataWrapper {
}
